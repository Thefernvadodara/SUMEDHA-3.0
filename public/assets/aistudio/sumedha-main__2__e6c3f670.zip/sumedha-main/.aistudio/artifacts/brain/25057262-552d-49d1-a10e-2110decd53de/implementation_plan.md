# Implementation Plan: Android Deployment & Installation Guide

**Application**: Sumedha Tech Infra - IT Service Manager  
**Package / Application ID**: `com.sumedha.techinfra`  
**Target Platform**: Android (Web PWA & Native Jetpack Compose / Android Studio Gradle Project)

---

## 1. Project Architecture Identification

### Analysis
- **Current Base**: Modern Full-Featured Web Application (React 19, TypeScript, Vite 8, Tailwind CSS v4, Motion).
- **Embedded Assets**: Contains native Jetpack Compose Material 3 reference code inside the UI (`JetpackComposeCodeViewer.tsx`), but was previously running exclusively as a standard browser SPA.
- **Decision**:
  1. **Primary Immediate Path**: Transform the existing web app into a high-performance, mobile-optimized **Progressive Web App (PWA)** that can be installed on any Android phone directly via Chrome/Samsung Internet with 1 tap, offline caching, and native app launcher presence.
  2. **Native Android Path**: Generate a complete, standalone **Android Gradle Project** in `/android` ready to import into Android Studio to compile Debug or Release APKs (`.apk`) and Android App Bundles (`.aab`).

---

## 2. Progressive Web App (PWA) Implementation

### A. Web App Manifest & Service Worker
- **Dependency**: Installed `vite-plugin-pwa` with TypeScript client declarations.
- **Configured `vite.config.ts`**:
  - `registerType: 'autoUpdate'`: Seamless background cache invalidation.
  - Manifest properties:
    - `id`: `/`
    - `name`: `Sumedha Tech Infra - IT Service Manager`
    - `short_name`: `Sumedha IT` (under 12 chars to prevent home screen text clipping)
    - `theme_color`: `#070b14` (matches dark Material 3 navy toolbar)
    - `background_color`: `#070b14` (splash screen background)
    - `display`: `standalone` (removes browser URL bar and navigation buttons)
    - `orientation`: `portrait-primary`
  - Workbox Cache Strategy:
    - Precaching of all JS bundles, CSS, HTML, SVG, and PNG assets.
    - `CacheFirst` runtime caching for Google Fonts stylesheets and static font files (1-year cache TTL).
    - `devOptions.enabled: true` for full preview testing.

### B. Mobile Meta Tags & Viewport
- **Updated `index.html`**:
  - `viewport`: `width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover` (supports notch and gesture navigation bar safe areas).
  - Web App Capable tags for mobile browsers (`mobile-web-app-capable`, `apple-mobile-web-app-capable`).
  - Icons and apple-touch-icon links.

### C. Icon Assets (`/public`)
- `icon.svg`: Crisp vector icon with navy squircle, server rack layers, LED indicators, and glowing cyan shield.
- `pwa-192x192.png`: 192px standard home screen icon.
- `pwa-512x512.png`: 512px high-res splash screen icon.
- `pwa-maskable-512x512.png`: Maskable icon with 15% safe-zone margin for Android circular and squircle adaptive icon cutouts.
- `apple-touch-icon.png`: 180px PNG icon for iOS Safari.
- `favicon.ico`: Desktop browser favicon.

### D. In-App Install Prompt & Offline Resiliency
- `src/hooks/usePWAInstall.ts`: Intercepts `beforeinstallprompt`, tracks standalone installation state, and provides programmatic 1-tap installation.
- `src/components/PWA/PWAInstallButton.tsx`: Mounted in `TopBar.tsx`. Suppresses itself when already running in standalone mode, displays an "Installed" badge, and triggers browser install prompt.
- `src/hooks/useOnlineStatus.ts` & `src/components/PWA/OfflineIndicator.tsx`: Detects network loss and displays a non-intrusive offline status banner.
- `src/components/Modals/AndroidInstallGuideModal.tsx`: Visual walkthrough explaining Chrome installation on Android and command-line APK compilation.

---

## 3. Native Android Project Structure (`/android`)

A complete, production-ready Android Studio Gradle project has been generated in the root `/android/` directory:

```
android/
├── build.gradle.kts                      # Root Gradle build script
├── settings.gradle.kts                   # Project settings & dependency repositories
├── gradle.properties                     # JVM args, AndroidX, and non-transitive R class
├── gradlew                               # Gradle wrapper executable
├── README.md                             # Step-by-step build documentation
├── gradle/
│   ├── libs.versions.toml                # Gradle Version Catalog (AGP 8.7, Kotlin 2.0, Compose BOM)
│   └── wrapper/
│       └── gradle-wrapper.properties     # Gradle 8.9 distribution URL
└── app/
    ├── build.gradle.kts                  # App module with Compose & WebKit
    ├── proguard-rules.pro                # Release optimization & obfuscation rules
    └── src/
        └── main/
            ├── AndroidManifest.xml       # Permissions (INTERNET, ACCESS_NETWORK_STATE) & MainActivity
            ├── java/com/sumedha/techinfra/
            │   ├── MainActivity.kt       # Hybrid Single Activity (Compose + Hardware WebView)
            │   ├── theme/
            │   │   ├── Color.kt          # Material 3 Sumedha color palette
            │   │   └── Theme.kt          # Dark Color Scheme & System Status Bar controller
            │   └── ui/
            │       └── SumedhaDashboardScreen.kt # Native Jetpack Compose Dashboard screen
            └── res/
                ├── values/
                │   ├── strings.xml       # App title and localized strings
                │   ├── colors.xml        # Theme color definitions
                │   └── themes.xml        # Material NoActionBar theme
                ├── drawable/
                │   ├── ic_launcher_background.xml
                │   └── ic_launcher_foreground.xml
                └── mipmap-anydpi-v26/
                    ├── ic_launcher.xml
                    └── ic_launcher_round.xml
```

---

## 4. How to Deploy and Install on Android

### Option A: Install via Browser (PWA - Recommended & Instant)
1. **Deploy**: Host the built web app (e.g., on Cloud Run, Vercel, Firebase Hosting, or Cloudflare Pages).
2. **Open**: On your Android phone, open Google Chrome and navigate to the application URL.
3. **Install**:
   - Either tap the **"Install on Android"** button directly in the top navigation bar.
   - Or tap Chrome's menu **(⋮)** > select **"Install app"** or **"Add to Home screen"**.
4. **Result**: An icon with the Sumedha Tech Infra emblem will be placed on your home screen and app drawer. It launches fullscreen without URL bars, with instant loading from the Service Worker cache.

### Option B: Build the Native APK via Android Studio
1. Install **Android Studio** (Ladybug, Iguana, or Hedgehog).
2. Click **Open** and select the `/android` folder in this repository.
3. Allow Gradle to sync dependencies automatically.
4. Plug in your Android phone via USB (with **USB Debugging** enabled in Developer Settings).
5. Click **Run 'app' (▶)**. Android Studio builds the APK and installs it directly on your device.

### Option C: Build the APK via Command Line
If you have the Android SDK and Java 17 installed:
```bash
# Navigate to the android folder
cd android

# Build the Debug APK
./gradlew assembleDebug

# Output APK path:
# android/app/build/outputs/apk/debug/app-debug.apk

# Sideload directly to connected phone:
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

For release signing:
```bash
./gradlew assembleRelease
# Output: android/app/build/outputs/apk/release/app-release-unsigned.apk
```

---

## 5. Summary of Created & Modified Files

| Category | File | Description |
|---|---|---|
| **PWA Configuration** | `vite.config.ts` | Configured `VitePWA` with auto-updates, manifest, and Workbox caching |
| **TypeScript** | `tsconfig.json` | Added `vite-plugin-pwa/client` types |
| **HTML Entry** | `index.html` | Added mobile viewport, theme colors, and PWA icon links |
| **PWA Icons** | `public/icon.svg` | Branded high-contrast SVG vector icon |
| **PWA Icons** | `public/pwa-192x192.png` | 192x192 standard icon |
| **PWA Icons** | `public/pwa-512x512.png` | 512x512 splash screen icon |
| **PWA Icons** | `public/pwa-maskable-512x512.png` | 512x512 maskable icon with safe zone padding |
| **PWA Icons** | `public/apple-touch-icon.png` | 180x180 PNG icon for iOS |
| **PWA Icons** | `public/favicon.ico` | Desktop favicon |
| **PWA Hooks** | `src/hooks/usePWAInstall.ts` | Detects installability, standalone mode, and triggers install prompt |
| **PWA Hooks** | `src/hooks/useOnlineStatus.ts` | Online/offline connectivity tracking |
| **PWA Components** | `src/components/PWA/PWAInstallButton.tsx` | Header install action button |
| **PWA Components** | `src/components/PWA/OfflineIndicator.tsx` | Offline notification banner |
| **PWA Modals** | `src/components/Modals/AndroidInstallGuideModal.tsx` | Interactive modal with PWA and APK build steps |
| **Main UI** | `src/components/TopBar.tsx` | Integrated `PWAInstallButton` in header actions |
| **Main UI** | `src/components/Views/MoreView.tsx` | Added install guide trigger to Android inspector section |
| **Main UI** | `src/App.tsx` | Mounted `AndroidInstallGuideModal` and `OfflineIndicator` |
| **Android Project** | `android/settings.gradle.kts` | Multi-project setup & repository definitions |
| **Android Project** | `android/build.gradle.kts` | Root Gradle build script |
| **Android Project** | `android/gradle/libs.versions.toml` | Version catalog (AGP 8.7, Kotlin 2.0, Compose) |
| **Android Project** | `android/app/build.gradle.kts` | App module with Material 3, WebKit, and Android 15 SDK |
| **Android Project** | `android/app/src/main/AndroidManifest.xml` | App manifest with internet permissions & launcher |
| **Android Project** | `android/app/src/main/java/com/sumedha/techinfra/MainActivity.kt` | Single Activity with hybrid Compose/WebView fallback |
| **Android Project** | `android/app/src/main/java/com/sumedha/techinfra/ui/SumedhaDashboardScreen.kt` | Pure Jetpack Compose Dashboard screen |
| **Android Project** | `android/app/src/main/java/com/sumedha/techinfra/theme/` | Theme.kt and Color.kt with dark color scheme |
| **Android Resources** | `android/app/src/main/res/` | Adaptive vector icons, colors.xml, strings.xml, themes.xml |
| **Android Docs** | `android/README.md` | Complete build commands and sideloading steps |
