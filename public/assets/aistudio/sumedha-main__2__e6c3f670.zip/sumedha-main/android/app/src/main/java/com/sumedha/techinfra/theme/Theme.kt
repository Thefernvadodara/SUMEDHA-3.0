package com.sumedha.techinfra.theme

import android.app.Activity
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = SumedhaElectricCyan,
    onPrimary = Color(0xFF070B14),
    primaryContainer = Color(0xFF0B223F),
    secondary = SumedhaElectricBlue,
    background = SumedhaNavyDark,
    surface = SumedhaNavySurface,
    surfaceVariant = SumedhaNavyElevated,
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9),
    error = SumedhaRose
)

@Composable
fun SumedhaTechInfraTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = SumedhaNavyDark.toArgb()
            window.navigationBarColor = SumedhaNavyDark.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography(),
        content = content
    )
}
