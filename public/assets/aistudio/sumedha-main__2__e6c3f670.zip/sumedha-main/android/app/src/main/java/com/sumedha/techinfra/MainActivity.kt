package com.sumedha.techinfra

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.sumedha.techinfra.theme.SumedhaNavyDark
import com.sumedha.techinfra.theme.SumedhaTechInfraTheme
import com.sumedha.techinfra.ui.SumedhaDashboardScreen

class MainActivity : ComponentActivity() {

    // Hosted application URL (or fallback to native Material 3 Compose screen)
    private val appUrl = "https://ais-dev-dsnjrduttc3ysmtmayolcc-192362012988.asia-northeast1.run.app"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SumedhaTechInfraTheme {
                var useNativeCompose by remember { mutableStateOf(false) }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SumedhaNavyDark
                ) {
                    if (useNativeCompose) {
                        SumedhaDashboardScreen(
                            onSwitchToWeb = { useNativeCompose = false }
                        )
                    } else {
                        AppWebView(
                            url = appUrl,
                            onFallbackToNative = { useNativeCompose = true }
                        )
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AppWebView(
    url: String,
    onFallbackToNative: () -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    cacheMode = WebSettings.LOAD_DEFAULT
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    userAgentString = "$userAgentString SumedhaAndroidApp/1.0"
                }
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun onReceivedError(
                        view: WebView?,
                        errorCode: Int,
                        description: String?,
                        failingUrl: String?
                    ) {
                        super.onReceivedError(view, errorCode, description, failingUrl)
                        onFallbackToNative()
                    }
                }
                loadUrl(url)
            }
        }
    )
}
