package com.sumedha.techinfra.theme

import androidx.compose.ui.graphics.Color

val SumedhaNavyDark = Color(0xFF070B14)
val SumedhaNavySurface = Color(0xFF0C1527)
val SumedhaNavyElevated = Color(0xFF131F3B)
val SumedhaElectricCyan = Color(0xFF06B6D4)
val SumedhaNeonCyan = Color(0xFF22D3EE)
val SumedhaElectricBlue = Color(0xFF2563EB)
val SumedhaEmerald = Color(0xFF10B981)
val SumedhaAmber = Color(0xFFF59E0B)
val SumedhaRose = Color(0xFFF43F5E)
