# Sumedha Tech Infra - Android Project & APK Build Guide

This directory contains the complete native Android project for **Sumedha Tech Infra - IT Service Manager**.
It is configured with **Android Gradle Plugin 8.7**, **Kotlin 2.0**, **Jetpack Compose (Material 3)**, and hardware-accelerated **WebView / Trusted Web Activity** integration with offline caching.

---

## 1. Project Overview

- **Package ID / Application ID**: `com.sumedha.techinfra`
- **Target SDK**: Android 15 (API 35)
- **Minimum SDK**: Android 8.0 Oreo (API 26) - 99%+ of Android devices worldwide
- **UI Framework**: Material 3 & Jetpack Compose
- **Architecture**: Single Activity (`MainActivity.kt`) with dual runtime mode:
  1. **Hybrid PWA/WebView mode**: Renders live app with local hardware acceleration and Service Worker caching.
  2. **Native Compose mode**: Pure Jetpack Compose UI fallback.

---

## 2. Requirements

1. **Android Studio**: Android Studio Ladybug (2024.2+), Iguana, or Hedgehog.
2. **Java Development Kit**: JDK 17 or higher (bundled inside Android Studio).
3. **Android SDK**: API 35 SDK Platform & Build-Tools installed via SDK Manager.

---

## 3. How to Open in Android Studio

1. Launch Android Studio.
2. Choose **File > Open...** (or "Open Existing Project" from the welcome screen).
3. Browse to and select the `android` folder in this repository.
4. Android Studio will automatically resolve `settings.gradle.kts` and sync Gradle dependencies via the Version Catalog (`libs.versions.toml`).
5. Connect your Android phone via USB (with **USB Debugging** enabled in Developer Options) or start an Android Virtual Device (AVD).
6. Click the green **Run (▶)** button (Shift + F10) to install and launch directly on your device.

---

## 4. How to Build the APK via Command Line

Open your terminal, navigate to the `android` directory, and run:

### A. Build Debug APK (For immediate testing on any phone)
```bash
cd android
./gradlew assembleDebug
```
* The compiled APK will be generated at:
  `android/app/build/outputs/apk/debug/app-debug.apk`

### B. Build Release APK (For distribution)
```bash
cd android
./gradlew assembleRelease
```
* The release APK will be generated at:
  `android/app/build/outputs/apk/release/app-release-unsigned.apk`

### C. Build Android App Bundle (AAB for Google Play Store)
```bash
cd android
./gradlew bundleRelease
```
* The output bundle will be located at:
  `android/app/build/outputs/bundle/release/app-release.aab`

---

## 5. Installing the APK on an Android Phone (Sideloading)

### Method 1: Using ADB (Android Debug Bridge)
If your phone is plugged in with USB debugging:
```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

### Method 2: Direct File Transfer
1. Copy `app-debug.apk` to your phone via Google Drive, Telegram, WhatsApp, or USB file transfer.
2. Open the file on your Android phone.
3. Tap **Install** (if prompted, enable "Allow from this source" in Settings).

---

## 6. Instant PWA Alternative (No Build Tools Required)

If you do not have Android Studio installed on your current machine, the application is also 100% PWA compliant:
1. Open the hosted URL in Google Chrome on your Android phone.
2. Tap the Chrome menu (⋮) -> **Install app** or **Add to Home screen**.
3. The app installs immediately with custom icon, splash screen, and offline service worker.
