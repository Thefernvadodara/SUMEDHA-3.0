export type EquipmentType =
  | 'cctv_camera'
  | 'nvr_dvr'
  | 'desktop_pc'
  | 'laptop'
  | 'network_printer'
  | 'biometric_punch'
  | 'networking_switch'
  | 'wifi_ap'
  | 'server_rack'
  | 'epabx_system';

export type TicketPriority = 'urgent' | 'high' | 'medium' | 'low';
export type TicketStatus = 'pending' | 'in_progress' | 'solved' | 'on_hold';

export interface ServiceLocation {
  id: string;
  name: string;
  address: string;
  city: string;
  contactPerson: string;
  phone: string;
}

export interface Company {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  billingAddress: string;
  city: string;
  gstin: string;
  pan?: string;
  status: 'active' | 'deactivated';
  serviceLocations: ServiceLocation[];
  notes?: string;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  company: string;
  companyId?: string;
  customerIdCode?: string; // e.g. CUST-001
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  gstin?: string;
  notes?: string;
  amcStatus: 'Active AMC' | 'Comprehensive AMC' | 'On-Demand' | 'Expired';
  amcExpiryDate: string;
  installedEquipmentCount: number;
  activeTicketsCount: number;
  status?: 'active' | 'archived';
  createdAt?: string;
}

export interface Technician {
  id: string;
  name: string;
  role: string;
  avatarUrl: string;
  phone: string;
  email: string;
  activeTasks: number;
  completedThisMonth: number;
  totalTasks: number;
  rating: number; // e.g., 4.9
  completionRate: number; // percentage 0-100
  specializations: EquipmentType[];
  isAvailable: boolean;
}

export interface Ticket {
  id: string;
  title: string;
  customerId: string;
  customerName: string;
  customerCompany: string;
  customerPhone: string;
  location: string;
  equipmentType: EquipmentType;
  equipmentModel: string;
  serialNumber?: string;
  priority: TicketPriority;
  status: TicketStatus;
  technicianId: string;
  technicianName: string;
  technicianAvatar: string;
  createdAt: string;
  scheduledDate: string;
  description: string;
  resolutionNotes?: string;
  billable: boolean;
  estimatedCost?: number;
  slaTimeHours: number;
}

export type DocumentType =
  | 'quotation_without_gst'
  | 'quotation_with_gst'
  | 'invoice_without_gst'
  | 'invoice_with_gst';

export interface InvoiceLineItem {
  id: string;
  type: 'equipment' | 'spare_parts' | 'labour' | 'amc_service';
  description: string;
  partNumber?: string;
  serialNumbers?: string; // multi-line or comma-separated serial numbers
  hsnSac?: string; // HSN/SAC code e.g. 852190
  qty: number;
  unitPrice: number;
  discountPercent: number;
  taxPercent: number;
  taxAmount?: number; // calculated tax portion
  total: number;
}

export interface PaymentRecord {
  id: string;
  date: string;
  amount: number;
  method: 'UPI' | 'NEFT/RTGS' | 'Cheque' | 'Cash' | 'Card';
  referenceNumber?: string;
  notes?: string;
  recordedBy: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  details: string;
}

export interface Invoice {
  id: string;
  docType: DocumentType;
  invoiceNumber: string; // for invoices: e.g. 11/10/2026-1 or STI-INV-4092
  quoteNumber?: string; // for quotations: e.g. 31082026-1 or STI-QTN-101
  customerIdCode?: string;
  validUntil?: string; // for quotations
  ticketId?: string;
  customerId: string;
  customerName: string;
  companyId?: string;
  company: string;
  customerGstin?: string;
  customerAddress?: string;
  customerCity?: string;
  customerPhone?: string;
  amount: number; // subtotal before tax and discount
  discountTotal?: number;
  taxPercent?: number;
  taxAmount: number;
  taxType?: 'CGST_SGST' | 'IGST' | 'NONE';
  totalAmount: number; // grand total
  paidAmount?: number;
  balanceDue?: number;
  status: 'Draft' | 'Issued' | 'Paid' | 'Partial' | 'Pending' | 'Overdue' | 'Cancelled' | 'Accepted';
  dueDate: string;
  issuedDate: string;
  items: InvoiceLineItem[];
  payments?: PaymentRecord[];
  auditLogs?: AuditLogEntry[];
  cancellationReason?: string;
  notes?: string;
  terms?: string;
  linkedQuotationId?: string; // if created from a quotation
  linkedInvoiceId?: string; // if this quotation was converted to an invoice
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  type: 'ticket' | 'technician' | 'billing' | 'system';
  read: boolean;
  ticketId?: string;
}

export type ActiveTab = 'dashboard' | 'tasks' | 'customers' | 'billing' | 'more';

export type UserRole = 'admin' | 'technician';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  avatarUrl?: string;
  token: string;
}

export interface StaffAccount {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'Super Admin' | 'Operations Manager' | 'Senior Field Engineer' | 'Billing Specialist';
  permissions: string[];
  active: boolean;
  avatarUrl?: string;
}

export interface CompanyProfile {
  name: string;
  tagline: string;
  contactPerson: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  email: string;
  website: string;
  gstin: string;
  pan: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
  upiId: string;
  logoUrl?: string;
}

export interface BillingConfig {
  invoicePrefix: string;
  nextInvoiceNumber: number;
  quotationPrefix: string;
  nextQuotationNumber: number;
  defaultDueDays: number;
  defaultQuotationValidityDays: number;
  currency: string;
  defaultGstRate: number;
  defaultTaxType: 'CGST_SGST' | 'IGST';
  paymentMethods: string[];
  invoiceTerms: string;
  quotationTerms: string;
  quotationWiringNotice: string;
}

export interface SystemSettings {
  companyProfile: CompanyProfile;
  billingConfig: BillingConfig;
  staffAccounts: StaffAccount[];
}
