import React, { useState } from 'react';
import {
  Company,
  Customer,
  Invoice,
  StaffAccount,
  SystemSettings,
} from '../../types';
import { StorageService } from '../../services/storage';
import { AuthService, hashPassword, StoredUser } from '../../services/auth';
import {
  Building2,
  Users,
  CreditCard,
  Settings,
  Database,
  ShieldCheck,
  Save,
  Plus,
  Trash2,
  Edit2,
  Download,
  Upload,
  RotateCcw,
  Check,
  Search,
  ExternalLink,
  MapPin,
  FileSpreadsheet,
  Cloud,
  CheckCircle2,
  Layers,
  Archive,
  X,
  Camera,
  Image as ImageIcon,
  Eye,
  EyeOff,
} from 'lucide-react';
import { SumedhaDocumentHeader } from '../Document/SumedhaDocumentHeader';

interface SettingsAdminPanelProps {
  settings: SystemSettings;
  companies: Company[];
  customers: Customer[];
  invoices: Invoice[];
  onSaveSettings: (newSettings: SystemSettings) => void;
  onOpenCompanyModal: (company?: Company) => void;
  onOpenCompanyDetail: (company: Company) => void;
  onDeleteCompany: (company: Company) => void;
  onToggleCompanyStatus: (companyId: string) => void;
  showToast: (msg: string) => void;
  onResetAllData: () => void;
}

export const SettingsAdminPanel: React.FC<SettingsAdminPanelProps> = ({
  settings,
  companies,
  customers,
  invoices,
  onSaveSettings,
  onOpenCompanyModal,
  onOpenCompanyDetail,
  onDeleteCompany,
  onToggleCompanyStatus,
  showToast,
  onResetAllData,
}) => {
  const [subTab, setSubTab] = useState<
    'profile' | 'companies' | 'staff' | 'billing_config' | 'equipment' | 'backup'
  >('profile');

  // Company Profile form state
  const [profile, setProfile] = useState(settings.companyProfile);
  // Billing Config form state
  const [billingConfig, setBillingConfig] = useState(settings.billingConfig);
  // Staff Accounts
  const [staffList, setStaffList] = useState<StaffAccount[]>(settings.staffAccounts);

  // Staff Search & Modal
  const [staffSearch, setStaffSearch] = useState('');
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [editingStaffId, setEditingStaffId] = useState<string | null>(null);
  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPhone, setStaffPhone] = useState('+91 ');
  const [staffRole, setStaffRole] = useState<StaffAccount['role']>('Operations Manager');
  const [staffAvatarUrl, setStaffAvatarUrl] = useState<string>('');
  const [staffPassword, setStaffPassword] = useState('');
  const [staffConfirmPassword, setStaffConfirmPassword] = useState('');
  const [showStaffPassword, setShowStaffPassword] = useState(false);

  // Company Search filter
  const [companySearch, setCompanySearch] = useState('');

  // Equipment categories local state
