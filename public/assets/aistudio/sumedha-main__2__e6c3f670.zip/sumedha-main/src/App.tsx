/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ActiveTab,
  AuthUser,
  Company,
  Customer,
  DocumentType,
  Invoice,
  NotificationItem,
  PaymentRecord,
  SystemSettings,
  Technician,
  Ticket,
  TicketStatus,
} from './types';
import {
  INITIAL_COMPANIES,
  INITIAL_CUSTOMERS,
  INITIAL_INVOICES,
  INITIAL_NOTIFICATIONS,
  INITIAL_SETTINGS,
  INITIAL_TECHNICIANS,
  INITIAL_TICKETS,
} from './data/mockData';
import { StorageService } from './services/storage';
import { AuthService } from './services/auth';

// Components
import { TopBar } from './components/TopBar';
import { HeroServiceOverview } from './components/HeroServiceOverview';
import { StatsGrid } from './components/StatsGrid';
import { StatusDonutChart } from './components/Charts/StatusDonutChart';
import { WeeklyBarChart } from './components/Charts/WeeklyBarChart';
import { RecentServiceCalls } from './components/RecentServiceCalls';
import { TechnicianPerformance } from './components/TechnicianPerformance';
import { MonthlyBillingOverview } from './components/MonthlyBillingOverview';
import { QuickActions } from './components/QuickActions';
import { BottomNavBar } from './components/BottomNavBar';
import { FloatingActionButton } from './components/FloatingActionButton';

// Views
import { TasksView } from './components/Views/TasksView';
import { CustomersView } from './components/Views/CustomersView';
import { BillingView } from './components/Views/BillingView';
import { MoreView } from './components/Views/MoreView';
import { DashboardLoadingSkeleton, ErrorState } from './components/FeedbackStates';

// Modals
import { NewTaskModal } from './components/Modals/NewTaskModal';
import { AddCustomerModal } from './components/Modals/AddCustomerModal';
import { CreateInvoiceModal } from './components/Modals/CreateInvoiceModal';
import { ReportsModal } from './components/Modals/ReportsModal';
import { TicketDetailModal } from './components/Modals/TicketDetailModal';
import { AndroidInstallGuideModal } from './components/Modals/AndroidInstallGuideModal';
import { CompanyModal } from './components/Modals/CompanyModal';
import { CompanyDetailModal } from './components/Modals/CompanyDetailModal';
import { CustomerDetailModal } from './components/Modals/CustomerDetailModal';
import { InvoiceDetailModal } from './components/Modals/InvoiceDetailModal';
import { DeleteConfirmModal } from './components/Modals/DeleteConfirmModal';

// Auth Screen
import { LoginScreen } from './components/Auth/LoginScreen';

// PWA
import { OfflineIndicator } from './components/PWA/OfflineIndicator';

export default function App() {
  // Authentication & Session state
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() =>
    AuthService.getCurrentSession()
  );

  // Persistent Application Data States
  const [companies, setCompanies] = useState<Company[]>(() => StorageService.getCompanies());
  const [customers, setCustomers] = useState<Customer[]>(() => StorageService.getCustomers());
  const [tickets, setTickets] = useState<Ticket[]>(() => StorageService.getTickets());
  const [invoices, setInvoices] = useState<Invoice[]>(() => StorageService.getInvoices());
  const [technicians, setTechnicians] = useState<Technician[]>(() => StorageService.getTechnicians());
  const [notifications, setNotifications] = useState<NotificationItem[]>(() =>
    StorageService.getNotifications()
  );
  const [settings, setSettings] = useState<SystemSettings>(() => StorageService.getSettings());

  // Navigation & Viewport Mode
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [deviceView, setDeviceView] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [selectedFilter, setSelectedFilter] = useState<TicketStatus | 'all' | null>(null);

  // Operational Modals
  const [isNewTaskOpen, setIsNewTaskOpen] = useState(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [isCreateInvoiceOpen, setIsCreateInvoiceOpen] = useState(false);
  const [initialDocTypeForCreate, setInitialDocTypeForCreate] = useState<DocumentType>('invoice_with_gst');
  const [preselectedInvoiceCustId, setPreselectedInvoiceCustId] = useState<string | undefined>(undefined);
  const [isReportsOpen, setIsReportsOpen] = useState(false);
  const [activeTicketDetail, setActiveTicketDetail] = useState<Ticket | null>(null);
  const [isInstallGuideOpen, setIsInstallGuideOpen] = useState(false);

  // Enhanced Management Modals
  const [activeCustomerDetail, setActiveCustomerDetail] = useState<Customer | null>(null);
  const [activeCompanyDetail, setActiveCompanyDetail] = useState<Company | null>(null);
  const [activeInvoiceDetail, setActiveInvoiceDetail] = useState<Invoice | null>(null);
  const [companyModalState, setCompanyModalState] = useState<{
    isOpen: boolean;
    existingCompany: Company | null;
  }>({ isOpen: false, existingCompany: null });

  // Delete Confirmation Modal State
  const [deleteConfirmState, setDeleteConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    itemName: string;
    itemType: 'customer' | 'company' | 'invoice' | 'staff' | 'task';
    linkedCounts?: { tickets?: number; invoices?: number; customers?: number };
    onConfirmDelete: () => void;
    onConfirmArchive?: () => void;
    isArchived?: boolean;
  }>({
    isOpen: false,
    title: '',
    itemName: '',
    itemType: 'customer',
    onConfirmDelete: () => {},
  });

  // Feedback States (loading & error simulators)
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // -------------------------------------------------------------
  // AUTHENTICATION HANDLERS
  // -------------------------------------------------------------
  const handleLogout = () => {
    AuthService.logout();
    setCurrentUser(null);
    showToast('Session ended. You have been logged out.');
  };

  // -------------------------------------------------------------
  // CUSTOMER MANAGEMENT HANDLERS
  // -------------------------------------------------------------
  const handleSaveCustomer = (custData: Partial<Customer>) => {
    let updatedList: Customer[];

    if (editingCustomer) {
      updatedList = customers.map((c) =>
        c.id === editingCustomer.id ? ({ ...c, ...custData } as Customer) : c
      );
      showToast(`Client "${custData.name}" updated successfully.`);
    } else {
      const newCust: Customer = {
        id: `cust-${Date.now()}`,
        name: custData.name || 'New Client',
        company: custData.company || 'Enterprise Entity',
        companyId: custData.companyId,
        customerIdCode: custData.customerIdCode || `CUST-${Math.floor(1000 + Math.random() * 9000)}`,
        contactPerson: custData.contactPerson || 'Authorized Contact',
        phone: custData.phone || '+91 98000 00000',
        email: custData.email || 'client@domain.com',
        address: custData.address || 'Facility Site',
        city: custData.city || 'Vadodara',
        gstin: custData.gstin,
        notes: custData.notes,
        amcStatus: custData.amcStatus || 'On-Demand',
        amcExpiryDate: custData.amcExpiryDate || '2027-12-31',
        installedEquipmentCount: custData.installedEquipmentCount || 0,
        activeTicketsCount: 0,
        status: 'active',
        createdAt: new Date().toISOString().split('T')[0],
      };
      updatedList = [newCust, ...customers];
      showToast(`Client "${newCust.name}" registered successfully.`);
    }

    setCustomers(updatedList);
    StorageService.saveCustomers(updatedList);
    setIsAddCustomerOpen(false);
    setEditingCustomer(null);

    if (activeCustomerDetail && editingCustomer && activeCustomerDetail.id === editingCustomer.id) {
      setActiveCustomerDetail({ ...activeCustomerDetail, ...custData } as Customer);
    }
  };

  const handleDeleteCustomerPrompt = (cust: Customer) => {
    const linkedTicketsCount = tickets.filter((t) => t.customerId === cust.id).length;
    const linkedInvoicesCount = invoices.filter((i) => i.customerId === cust.id).length;

    setDeleteConfirmState({
      isOpen: true,
      title: 'Delete Customer Account',
      itemName: cust.name,
      itemType: 'customer',
      linkedCounts: {
        tickets: linkedTicketsCount,
        invoices: linkedInvoicesCount,
      },
      isArchived: cust.status === 'archived',
      onConfirmArchive: () => {
        const newStatus: 'active' | 'archived' = cust.status === 'archived' ? 'active' : 'archived';
        const updated = customers.map((c) => (c.id === cust.id ? { ...c, status: newStatus } : c));
        setCustomers(updated);
        StorageService.saveCustomers(updated);
        if (activeCustomerDetail && activeCustomerDetail.id === cust.id) {
          setActiveCustomerDetail({ ...cust, status: newStatus });
        }
        showToast(`Client ${cust.name} marked as ${newStatus}.`);
      },
      onConfirmDelete: () => {
        const updated = customers.filter((c) => c.id !== cust.id);
        setCustomers(updated);
        StorageService.saveCustomers(updated);
        if (activeCustomerDetail && activeCustomerDetail.id === cust.id) {
          setActiveCustomerDetail(null);
        }
        showToast(`Client "${cust.name}" deleted permanently.`);
      },
    });
  };

  // -------------------------------------------------------------
  // COMPANY MANAGEMENT HANDLERS
  // -------------------------------------------------------------
  const handleSaveCompany = (companyData: Partial<Company>) => {
    let updated: Company[];
    if (companyModalState.existingCompany) {
      updated = companies.map((c) =>
        c.id === companyModalState.existingCompany?.id ? ({ ...c, ...companyData } as Company) : c
      );
      showToast(`Company "${companyData.name}" updated successfully.`);
    } else {
      const newComp: Company = {
        id: `comp-${Date.now()}`,
        name: companyData.name || 'New Company',
        contactPerson: companyData.contactPerson || '',
        phone: companyData.phone || '',
        email: companyData.email || '',
        billingAddress: companyData.billingAddress || '',
        city: companyData.city || 'Vadodara',
        gstin: companyData.gstin || '',
        pan: companyData.pan,
        status: 'active',
        serviceLocations: companyData.serviceLocations || [],
        notes: companyData.notes,
        createdAt: new Date().toISOString().split('T')[0],
      };
      updated = [newComp, ...companies];
      showToast(`Company "${newComp.name}" registered successfully.`);
    }

    setCompanies(updated);
    StorageService.saveCompanies(updated);
    setCompanyModalState({ isOpen: false, existingCompany: null });

    if (activeCompanyDetail && companyModalState.existingCompany && activeCompanyDetail.id === companyModalState.existingCompany.id) {
      setActiveCompanyDetail({ ...activeCompanyDetail, ...companyData } as Company);
    }
  };

  const handleToggleCompanyStatus = (companyId: string) => {
    const updated = companies.map((c) =>
      c.id === companyId
        ? { ...c, status: (c.status === 'active' ? 'deactivated' : 'active') as 'active' | 'deactivated' }
        : c
    );
    setCompanies(updated);
    StorageService.saveCompanies(updated);
    const target = updated.find((c) => c.id === companyId);
    showToast(`Company "${target?.name}" is now ${target?.status}.`);
  };

  const handleDeleteCompanyPrompt = (comp: Company) => {
    const linkedCusts = customers.filter(
      (c) => c.companyId === comp.id || c.company.toLowerCase() === comp.name.toLowerCase()
    ).length;

    setDeleteConfirmState({
      isOpen: true,
      title: 'Delete Customer Company',
      itemName: comp.name,
      itemType: 'company',
      linkedCounts: {
        customers: linkedCusts,
      },
      isArchived: comp.status === 'deactivated',
      onConfirmArchive: () => {
        handleToggleCompanyStatus(comp.id);
      },
      onConfirmDelete: () => {
        const updated = companies.filter((c) => c.id !== comp.id);
        setCompanies(updated);
        StorageService.saveCompanies(updated);
        if (activeCompanyDetail && activeCompanyDetail.id === comp.id) {
          setActiveCompanyDetail(null);
        }
        showToast(`Company "${comp.name}" removed.`);
      },
    });
  };

  // -------------------------------------------------------------
  // INVOICE & QUOTATION BILLING HANDLERS
  // -------------------------------------------------------------
  const handleOpenCreateDocument = (type?: DocumentType) => {
    if (currentUser?.role !== 'admin') {
      showToast('Admin authorization required to create invoices and quotations.');
      return;
    }
    setInitialDocTypeForCreate(type || 'invoice_with_gst');
    setPreselectedInvoiceCustId(undefined);
    setIsCreateInvoiceOpen(true);
  };

  const handleCreateInvoice = (newInvoice: Invoice) => {
    const isQuote =
      newInvoice.docType === 'quotation_without_gst' ||
      newInvoice.docType === 'quotation_with_gst';

    let updatedSettings = settings;
    if (isQuote) {
      const nextQ = (settings.billingConfig.nextQuotationNumber || 1) + 1;
      updatedSettings = {
        ...settings,
        billingConfig: { ...settings.billingConfig, nextQuotationNumber: nextQ },
      };
    } else {
      const nextI = (settings.billingConfig.nextInvoiceNumber || 1) + 1;
      updatedSettings = {
        ...settings,
        billingConfig: { ...settings.billingConfig, nextInvoiceNumber: nextI },
      };
    }

    const updated = [newInvoice, ...invoices];
    setInvoices(updated);
    StorageService.saveInvoices(updated);
    setSettings(updatedSettings);
    StorageService.saveSettings(updatedSettings);

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: `${isQuote ? 'Quotation' : 'Invoice'} Generated #${newInvoice.invoiceNumber || newInvoice.quoteNumber || newInvoice.id}`,
      message: `${isQuote ? 'Price proposal' : 'Tax invoice'} of ₹${newInvoice.totalAmount.toLocaleString('en-IN')} issued to ${newInvoice.customerName}.`,
      time: 'Just now',
      type: 'billing',
      read: false,
    };
    const updatedNotifs = [newNotif, ...notifications];
    setNotifications(updatedNotifs);
    StorageService.saveNotifications(updatedNotifs);

    showToast(
      `${isQuote ? 'Quotation' : 'Invoice'} #${newInvoice.invoiceNumber || newInvoice.quoteNumber || newInvoice.id} generated!`
    );
  };

  const handleConvertToInvoice = (
    quotation: Invoice,
    targetDocType: 'invoice_with_gst' | 'invoice_without_gst'
  ) => {
    if (currentUser?.role !== 'admin') {
      showToast('Admin authorization required to convert quotation to invoice.');
      return;
    }

    const nextInvNum = settings.billingConfig.nextInvoiceNumber || 2;
    const newInvoiceNumber = `${settings.billingConfig.invoicePrefix || '11/10/2026-'}${nextInvNum}`;

    const newInvoice: Invoice = {
      ...quotation,
      id: `inv-${Date.now()}`,
      docType: targetDocType,
      invoiceNumber: newInvoiceNumber,
      quoteNumber: quotation.invoiceNumber || quotation.quoteNumber,
      linkedQuotationId: quotation.invoiceNumber || quotation.quoteNumber || quotation.id,
      issuedDate: new Date().toLocaleDateString('en-GB'),
      dueDate: new Date(Date.now() + (settings.billingConfig.defaultDueDays || 15) * 86400000)
        .toLocaleDateString('en-GB'),
      status: 'Pending',
      paidAmount: 0,
      balanceDue: quotation.totalAmount,
      terms: settings.billingConfig.invoiceTerms,
      auditLogs: [
        {
          id: `audit-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'Quotation Converted to Invoice',
          actor: currentUser?.name || 'Hardik Patel',
          details: `Converted Quotation #${quotation.invoiceNumber || quotation.id} to ${
            targetDocType === 'invoice_with_gst' ? 'GST Tax Invoice' : 'Commercial Invoice'
          } #${newInvoiceNumber}.`,
        },
      ],
    };

    // Mark quotation as accepted
    const updatedQuotation: Invoice = {
      ...quotation,
      status: 'Accepted',
      linkedInvoiceId: newInvoiceNumber,
    };

    const updatedInvoices = [
      newInvoice,
      ...invoices.map((inv) => (inv.id === quotation.id ? updatedQuotation : inv)),
    ];

    const updatedSettings: SystemSettings = {
      ...settings,
      billingConfig: {
        ...settings.billingConfig,
        nextInvoiceNumber: nextInvNum + 1,
      },
    };

    setInvoices(updatedInvoices);
    StorageService.saveInvoices(updatedInvoices);
    setSettings(updatedSettings);
    StorageService.saveSettings(updatedSettings);

    setActiveInvoiceDetail(newInvoice);
    showToast(`Quotation converted to Invoice #${newInvoiceNumber}! Original quote preserved.`);
  };

  const handleUpdateInvoiceStatus = (invoiceId: string, status: Invoice['status']) => {
    const updated = invoices.map((inv) =>
      inv.id === invoiceId
        ? {
            ...inv,
            status,
            auditLogs: [
              ...(inv.auditLogs || []),
              {
                id: `audit-${Date.now()}`,
                timestamp: new Date().toISOString(),
                action: `Status Updated to ${status}`,
                actor: currentUser?.name || 'Administrator',
                details: `Document status updated to ${status}.`,
              },
            ],
          }
        : inv
    );
    setInvoices(updated);
    StorageService.saveInvoices(updated);
    showToast(`Document status changed to ${status}.`);
  };

  const handleRecordPayment = (invoiceId: string, payment: PaymentRecord) => {
    const updated = invoices.map((inv) => {
      if (inv.id !== invoiceId) return inv;
      const currentPaid = inv.paidAmount || 0;
      const newPaid = currentPaid + payment.amount;
      const newBalance = Math.max(0, inv.totalAmount - newPaid);
      const newStatus: Invoice['status'] = newBalance <= 0 ? 'Paid' : 'Partial';

      const updatedAudit = [
        ...(inv.auditLogs || []),
        {
          id: `audit-${Date.now()}`,
          timestamp: new Date().toISOString(),
          action: 'Payment Received',
          actor: currentUser?.name || payment.recordedBy,
          details: `Received ₹${payment.amount.toLocaleString('en-IN')} via ${payment.method}. Outstanding balance: ₹${newBalance.toLocaleString('en-IN')}.`,
        },
      ];

      return {
        ...inv,
        paidAmount: newPaid,
        balanceDue: newBalance,
        status: newStatus,
        payments: [...(inv.payments || []), payment],
        auditLogs: updatedAudit,
      };
    });

    setInvoices(updated);
    StorageService.saveInvoices(updated);
    const target = updated.find((i) => i.id === invoiceId);
    if (activeInvoiceDetail && activeInvoiceDetail.id === invoiceId && target) {
      setActiveInvoiceDetail(target);
    }
    showToast(`Payment of ₹${payment.amount.toLocaleString('en-IN')} recorded successfully.`);
  };

  const handleCancelInvoice = (invoiceId: string, reason: string) => {
    const updated = invoices.map((inv) => {
      if (inv.id !== invoiceId) return inv;
      return {
        ...inv,
        status: 'Cancelled' as const,
        cancellationReason: reason,
        auditLogs: [
          ...(inv.auditLogs || []),
          {
            id: `audit-${Date.now()}`,
            timestamp: new Date().toISOString(),
            action: 'Document Cancelled',
            actor: currentUser?.name || 'Hardik Patel',
            details: `Cancelled. Authorized Reason: ${reason}`,
          },
        ],
      };
    });

    setInvoices(updated);
    StorageService.saveInvoices(updated);
    const target = updated.find((i) => i.id === invoiceId);
    if (activeInvoiceDetail && activeInvoiceDetail.id === invoiceId && target) {
      setActiveInvoiceDetail(target);
    }
    showToast(`Document cancelled and audit recorded.`);
  };

  // -------------------------------------------------------------
  // SETTINGS HANDLER
  // -------------------------------------------------------------
  const handleSaveSettings = (newSettings: SystemSettings) => {
    setSettings(newSettings);
    StorageService.saveSettings(newSettings);
    showToast('System configuration saved persistently.');
  };

  // -------------------------------------------------------------
  // TICKET & OPERATIONS HANDLERS
  // -------------------------------------------------------------
  const handleCreateTicket = (newTicketData: Partial<Ticket>) => {
    const cust = customers.find((c) => c.id === newTicketData.customerId) || customers[0];
    const tech = technicians.find((t) => t.id === newTicketData.technicianId) || technicians[0];

    const ticket: Ticket = {
      id: `STI-${Math.floor(8850 + Math.random() * 200)}`,
      title: newTicketData.title || 'Unscheduled Infrastructure Task',
      customerId: cust.id,
      customerName: cust.name,
      customerCompany: cust.company,
      customerPhone: cust.phone,
      location: newTicketData.location || `${cust.address}, ${cust.city}`,
      equipmentType: newTicketData.equipmentType || 'cctv_camera',
      equipmentModel: newTicketData.equipmentModel || 'Hardware Unit',
      serialNumber: newTicketData.serialNumber,
      priority: newTicketData.priority || 'medium',
      status: 'pending',
      technicianId: tech.id,
      technicianName: tech.name,
      technicianAvatar: tech.avatarUrl,
      createdAt: 'Just now',
      scheduledDate: newTicketData.scheduledDate || 'Today, 02:00 PM',
      description: newTicketData.description || 'Service call dispatched via operations.',
      billable: newTicketData.billable ?? true,
      estimatedCost: newTicketData.estimatedCost || 1500,
      slaTimeHours: newTicketData.slaTimeHours || 8,
    };

    const updatedTickets = [ticket, ...tickets];
    setTickets(updatedTickets);
    StorageService.saveTickets(updatedTickets);

    const newNotification: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: `New Dispatch: ${ticket.title}`,
      message: `Assigned to ${ticket.technicianName} for ${ticket.customerName}.`,
      time: 'Just now',
      type: 'ticket',
      read: false,
      ticketId: ticket.id,
    };
    const updatedNotifs = [newNotification, ...notifications];
    setNotifications(updatedNotifs);
    StorageService.saveNotifications(updatedNotifs);

    showToast(`Service task #${ticket.id} dispatched to ${ticket.technicianName}!`);
  };

  const handleUpdateStatus = (ticketId: string, status: TicketStatus) => {
    const updatedTickets = tickets.map((t) => (t.id === ticketId ? { ...t, status } : t));
    setTickets(updatedTickets);
    StorageService.saveTickets(updatedTickets);

    const targetTicket = tickets.find((t) => t.id === ticketId);
    if (targetTicket) {
      const newNotif: NotificationItem = {
        id: `notif-${Date.now()}`,
        title: `Task #${ticketId} Status: ${status.toUpperCase()}`,
        message: `${targetTicket.title} marked as ${status.replace('_', ' ')}.`,
        time: 'Just now',
        type: 'ticket',
        read: false,
        ticketId: ticketId,
      };
      const updatedNotifs = [newNotif, ...notifications];
      setNotifications(updatedNotifs);
      StorageService.saveNotifications(updatedNotifs);
    }

    if (activeTicketDetail && activeTicketDetail.id === ticketId) {
      setActiveTicketDetail({ ...activeTicketDetail, status });
    }

    showToast(`Ticket #${ticketId} marked as ${status.replace('_', ' ')}`);
  };

  const handleUpdateTicket = (updatedTicket: Ticket) => {
    const updated = tickets.map((t) => (t.id === updatedTicket.id ? updatedTicket : t));
    setTickets(updated);
    StorageService.saveTickets(updated);
    setActiveTicketDetail(updatedTicket);
    showToast(`Ticket #${updatedTicket.id} updated successfully.`);
  };

  const handleMarkNotificationRead = (id: string) => {
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    setNotifications(updated);
    StorageService.saveNotifications(updated);
  };

  const handleClearAllNotifications = () => {
    const updated = notifications.map((n) => ({ ...n, read: true }));
    setNotifications(updated);
    StorageService.saveNotifications(updated);
    showToast('All notifications marked as read.');
  };

  const handleOpenTicket = (ticketId: string) => {
    const found = tickets.find((t) => t.id === ticketId);
    if (found) {
      setActiveTicketDetail(found);
    }
  };

  const handleCallTechnician = (tech: Technician) => {
    showToast(`Initiating direct voice call to ${tech.name} (${tech.phone})...`);
  };

  const handleResetDemoData = () => {
    setCompanies(INITIAL_COMPANIES);
    setCustomers(INITIAL_CUSTOMERS);
    setTickets(INITIAL_TICKETS);
    setInvoices(INITIAL_INVOICES);
    setTechnicians(INITIAL_TECHNICIANS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setSettings(INITIAL_SETTINGS);

    StorageService.saveCompanies(INITIAL_COMPANIES);
    StorageService.saveCustomers(INITIAL_CUSTOMERS);
    StorageService.saveTickets(INITIAL_TICKETS);
    StorageService.saveInvoices(INITIAL_INVOICES);
    StorageService.saveTechnicians(INITIAL_TECHNICIANS);
    StorageService.saveNotifications(INITIAL_NOTIFICATIONS);
    StorageService.saveSettings(INITIAL_SETTINGS);

    showToast('Reset application to original Sumedha Tech Infra reference data.');
  };

  // If unauthenticated, display secure login screen
  if (!currentUser) {
    return (
      <LoginScreen
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          showToast(`Authenticated as ${user.name} (${user.role.toUpperCase()})`);
        }}
      />
    );
  }

  // Count active pending tasks
  const pendingTasksCount = tickets.filter(
    (t) => t.status === 'pending' || t.status === 'in_progress'
  ).length;

  // Filtered tickets if user clicked a stat card filter
  const displayedRecentTickets =
    selectedFilter && selectedFilter !== 'all'
      ? tickets.filter((t) => t.status === selectedFilter)
      : tickets;

  // Viewport Container styling:
  const getContainerClasses = () => {
    if (deviceView === 'mobile') {
      return 'w-full max-w-[430px] mx-auto min-h-screen my-4 rounded-[40px] border-[8px] border-slate-800 shadow-[0_0_50px_rgba(6,182,212,0.15)] overflow-hidden bg-[#070b14] relative';
    }
    if (deviceView === 'tablet') {
      return 'w-full max-w-[820px] mx-auto min-h-screen my-4 rounded-[32px] border-[8px] border-slate-800 shadow-[0_0_50px_rgba(6,182,212,0.15)] overflow-hidden bg-[#070b14] relative';
    }
    return 'w-full max-w-7xl mx-auto min-h-screen bg-[#070b14] relative';
  };

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 flex flex-col justify-between selection:bg-cyan-500/30">
      {/* Toast popup */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl bg-cyan-950/95 border border-cyan-400/50 text-cyan-200 text-xs font-semibold shadow-2xl flex items-center gap-2 animate-in fade-in slide-from-top-3 duration-200">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Responsive Wrapper */}
      <div className={getContainerClasses()}>
        {/* Top Header Bar */}
        <TopBar
          notifications={notifications}
          onMarkNotificationRead={handleMarkNotificationRead}
          onClearAllNotifications={handleClearAllNotifications}
          onOpenTicket={handleOpenTicket}
          deviceView={deviceView}
          onChangeDeviceView={setDeviceView}
          onOpenInstallGuide={() => setIsInstallGuideOpen(true)}
          currentUser={currentUser}
          onLogout={handleLogout}
        />

        {/* Dynamic Content Views */}
        <main className="p-4 sm:p-6 flex flex-col gap-6">
          {isLoading ? (
            <DashboardLoadingSkeleton />
          ) : isError ? (
            <ErrorState onRetry={() => setIsLoading(false)} />
          ) : activeTab === 'dashboard' ? (
            <>
              {/* 1. Hero Card: Service Overview */}
              <HeroServiceOverview
                tickets={tickets}
                onQuickNewTicket={() => setIsNewTaskOpen(true)}
              />

              {/* 2. 4 Graphic Statistic Cards */}
              <StatsGrid
                tickets={tickets}
                selectedFilter={selectedFilter}
                onSelectFilter={(status) => {
                  setSelectedFilter(status);
                  if (status !== 'all') {
                    showToast(`Filtered recent tickets by ${status.replace('_', ' ')}`);
                  }
                }}
              />

              {/* 3. Graphical Charts Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <StatusDonutChart
                  tickets={tickets}
                  selectedStatus={selectedFilter}
                  onSelectStatus={(status) => setSelectedFilter(status as TicketStatus | null)}
                />
                <WeeklyBarChart />
              </div>

              {/* 4. Quick Action Buttons */}
              <QuickActions
                onNewTask={() => setIsNewTaskOpen(true)}
                onAddCustomer={() => {
                  setEditingCustomer(null);
                  setIsAddCustomerOpen(true);
                }}
                onCreateInvoice={() => handleOpenCreateDocument('invoice_with_gst')}
                onViewReports={() => setIsReportsOpen(true)}
              />

              {/* 5. Recent Service Calls Section */}
              <RecentServiceCalls
                tickets={displayedRecentTickets}
                onSelectTicket={(ticket) => setActiveTicketDetail(ticket)}
                onUpdateStatus={handleUpdateStatus}
                onViewAllTasks={() => setActiveTab('tasks')}
              />

              {/* 6. Technician Dispatch Roster */}
              <TechnicianPerformance
                technicians={technicians}
                onCallTechnician={handleCallTechnician}
                onViewAllStaff={() => setActiveTab('more')}
              />

              {/* 7. Billing & Invoicing Snapshot */}
              <MonthlyBillingOverview
                invoices={invoices}
                onCreateInvoice={() => handleOpenCreateDocument('invoice_with_gst')}
                onViewAllInvoices={() => setActiveTab('billing')}
              />
            </>
          ) : activeTab === 'tasks' ? (
            <TasksView
              tickets={tickets}
              onSelectTicket={(ticket) => setActiveTicketDetail(ticket)}
              onUpdateStatus={handleUpdateStatus}
              onNewTask={() => setIsNewTaskOpen(true)}
            />
          ) : activeTab === 'customers' ? (
            <CustomersView
              customers={customers}
              companies={companies}
              tickets={tickets}
              invoices={invoices}
              onAddCustomer={() => {
                setEditingCustomer(null);
                setIsAddCustomerOpen(true);
              }}
              onEditCustomer={(cust) => {
                setEditingCustomer(cust);
                setIsAddCustomerOpen(true);
              }}
              onDeleteCustomer={handleDeleteCustomerPrompt}
              onOpenCustomerDetail={(cust) => setActiveCustomerDetail(cust)}
            />
          ) : activeTab === 'billing' ? (
            <BillingView
              invoices={invoices}
              onCreateDocument={handleOpenCreateDocument}
              onOpenInvoiceDetail={(inv) => setActiveInvoiceDetail(inv)}
              onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
            />
          ) : (
            <MoreView
              technicians={technicians}
              companies={companies}
              customers={customers}
              invoices={invoices}
              settings={settings}
              onSaveSettings={handleSaveSettings}
              onOpenCompanyModal={(comp) =>
                setCompanyModalState({ isOpen: true, existingCompany: comp || null })
              }
              onOpenCompanyDetail={(comp) => setActiveCompanyDetail(comp)}
              onDeleteCompany={handleDeleteCompanyPrompt}
              onToggleCompanyStatus={handleToggleCompanyStatus}
              onResetDemoData={handleResetDemoData}
              onToggleLoadingState={() => setIsLoading(!isLoading)}
              onToggleErrorState={() => setIsError(!isError)}
              isLoading={isLoading}
              isError={isError}
              onCallTechnician={handleCallTechnician}
              onOpenInstallGuide={() => setIsInstallGuideOpen(true)}
              showToast={showToast}
            />
          )}
        </main>

        {/* Floating Action Button for Emergency Ticket Dispatch */}
        <FloatingActionButton
          onNewTicket={() => setIsNewTaskOpen(true)}
          onAddCustomer={() => {
            setEditingCustomer(null);
            setIsAddCustomerOpen(true);
          }}
          onCreateInvoice={() => handleOpenCreateDocument('invoice_with_gst')}
        />

        {/* Material 3 Bottom Navigation Bar */}
        <BottomNavBar
          activeTab={activeTab}
          onChangeTab={setActiveTab}
          pendingTasksCount={pendingTasksCount}
        />
      </div>

      {/* ---------------- INTERACTIVE MODALS ---------------- */}
      {/* 1. New Service Task Modal */}
      <NewTaskModal
        isOpen={isNewTaskOpen}
        onClose={() => setIsNewTaskOpen(false)}
        customers={customers}
        technicians={technicians}
        onCreateTicket={handleCreateTicket}
      />

      {/* 2. Customer Form Modal (Add / Edit) */}
      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => {
          setIsAddCustomerOpen(false);
          setEditingCustomer(null);
        }}
        onSaveCustomer={handleSaveCustomer}
        existingCustomer={editingCustomer}
        companies={companies}
      />

      {/* 3. Customer Comprehensive Detail Modal */}
      <CustomerDetailModal
        customer={activeCustomerDetail}
        isOpen={activeCustomerDetail !== null}
        onClose={() => setActiveCustomerDetail(null)}
        tickets={tickets}
        invoices={invoices}
        onEditCustomer={(cust) => {
          setActiveCustomerDetail(null);
          setEditingCustomer(cust);
          setIsAddCustomerOpen(true);
        }}
        onDeleteCustomer={(cust) => {
          setActiveCustomerDetail(null);
          handleDeleteCustomerPrompt(cust);
        }}
        onNewTicketForCustomer={() => {
          setIsNewTaskOpen(true);
        }}
        onNewInvoiceForCustomer={(cust) => {
          setPreselectedInvoiceCustId(cust.id);
          setInitialDocTypeForCreate('invoice_with_gst');
          setIsCreateInvoiceOpen(true);
        }}
        onOpenTicketDetail={(ticket) => {
          setActiveCustomerDetail(null);
          setActiveTicketDetail(ticket);
        }}
        onOpenInvoiceDetail={(inv) => {
          setActiveCustomerDetail(null);
          setActiveInvoiceDetail(inv);
        }}
      />

      {/* 4. Company Modal (Add / Edit) */}
      <CompanyModal
        isOpen={companyModalState.isOpen}
        onClose={() => setCompanyModalState({ isOpen: false, existingCompany: null })}
        onSaveCompany={handleSaveCompany}
        existingCompany={companyModalState.existingCompany}
      />

      {/* 5. Company Comprehensive Detail Modal */}
      <CompanyDetailModal
        company={activeCompanyDetail}
        isOpen={activeCompanyDetail !== null}
        onClose={() => setActiveCompanyDetail(null)}
        customers={customers}
        tickets={tickets}
        invoices={invoices}
        onEditCompany={(comp) => {
          setActiveCompanyDetail(null);
          setCompanyModalState({ isOpen: true, existingCompany: comp });
        }}
        onToggleStatus={(companyId) => {
          handleToggleCompanyStatus(companyId);
        }}
        onOpenCustomerDetail={(cust) => {
          setActiveCompanyDetail(null);
          setActiveCustomerDetail(cust);
        }}
        onOpenInvoiceDetail={(inv) => {
          setActiveCompanyDetail(null);
          setActiveInvoiceDetail(inv);
        }}
      />

      {/* 6. Invoice Comprehensive Detail & Professional PDF Modal */}
      <InvoiceDetailModal
        invoice={activeInvoiceDetail}
        isOpen={activeInvoiceDetail !== null}
        onClose={() => setActiveInvoiceDetail(null)}
        settings={settings}
        onRecordPayment={handleRecordPayment}
        onCancelInvoice={handleCancelInvoice}
        onConvertToInvoice={handleConvertToInvoice}
      />

      {/* 7. Create Document (Invoice / Quotation) Modal */}
      <CreateInvoiceModal
        isOpen={isCreateInvoiceOpen}
        onClose={() => setIsCreateInvoiceOpen(false)}
        customers={customers}
        tickets={tickets}
        settings={settings}
        onCreateInvoice={handleCreateInvoice}
        preselectedCustomerId={preselectedInvoiceCustId}
        initialDocType={initialDocTypeForCreate}
      />

      {/* 8. Reports Modal */}
      <ReportsModal
        isOpen={isReportsOpen}
        onClose={() => setIsReportsOpen(false)}
      />

      {/* 9. Ticket Detail Modal */}
      <TicketDetailModal
        ticket={activeTicketDetail}
        isOpen={activeTicketDetail !== null}
        onClose={() => setActiveTicketDetail(null)}
        technicians={technicians}
        onUpdateTicket={handleUpdateTicket}
      />

      {/* 10. Audit Protected Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteConfirmState.isOpen}
        onClose={() => setDeleteConfirmState({ ...deleteConfirmState, isOpen: false })}
        title={deleteConfirmState.title}
        itemName={deleteConfirmState.itemName}
        itemType={deleteConfirmState.itemType}
        linkedCounts={deleteConfirmState.linkedCounts}
        isArchived={deleteConfirmState.isArchived}
        onConfirmDelete={deleteConfirmState.onConfirmDelete}
        onConfirmArchive={deleteConfirmState.onConfirmArchive}
      />

      {/* 11. Android Installation & APK Modal */}
      <AndroidInstallGuideModal
        isOpen={isInstallGuideOpen}
        onClose={() => setIsInstallGuideOpen(false)}
      />

      {/* 12. PWA Offline Mode Indicator */}
      <OfflineIndicator />
    </div>
  );
}
